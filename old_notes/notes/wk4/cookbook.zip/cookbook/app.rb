require 'sinatra'
require 'sinatra/reloader'
require 'active_record'
require 'sinatra/activerecord'

# load config
require "./config/environments"

set :environment, ENV["RACK_ENV"].to_sym
enable :sessions

# load models
require "./models/user.rb"
require "./models/ingredient.rb"
require "./models/recipe.rb"
require "./models/portion.rb"

# helper function
def authenticate!
	return redirect "/signin" unless session[:current_user]
	@user = User.find_by_name(session[:current_user])
end

# INGREDIENT logic

get '/ingredients/new' do 
	authenticate!
	erb :new_ingredient
end

post '/ingredients/create' do 
	ingredient_name = params[:name]
	Ingredient.create(name: ingredient_name)
	redirect "/"
end

# RECIPES logic

get '/' do 
	authenticate!

	@recipes = Recipe.all
	erb :index
end

get '/recipes/new' do
	authenticate!
	@ingredients = Ingredient.all
	erb :new_recipe
end

post '/recipes/create' do
	authenticate!

	# initialiaze ingredients list
	ingredient_names = []
	ingredients = []
	# iterate through params
	params.each do |key,value|
		if !key.scan("ingredient_").empty?
			ingredient_names << key.gsub("ingredient_","")
		end
	end

	ingredient_names.each do |name|
		ingredient = {
			name: name,
			amount: params[:ingredients][name][:amount],
			unit: params[:ingredients][name][:unit]
		}
		ingredients << ingredient
	end
	
	recipe = Recipe.new

	recipe.name = params[:name]
	recipe.user = User.find_by_name(params[:username])
	recipe.save!

	# attach ingredients
	ingredients.each do |ingredient|
		portion = Portion.create(
			ingredient: Ingredient.find_by_name(ingredient[:name]),
			amount: ingredient[:amount],
			unit: ingredient[:unit],
			recipe: recipe
		)
		recipe.portions << portion
	end

	recipe.save
	
	redirect "/"
end

get '/recipes/:id' do
	authenticate! 
	recipe = Recipe.find(params[:id])
	if recipe
		erb :show_recipe, locals: {recipe: recipe}
	else
		redirect "/"
	end
end

post '/recipes/:id/delete' do 
	authenticate!
	recipe = Recipe.find(params[:id])
	recipe.destroy
end

# USER logic

get "/signout" do 
	session[:current_user] = nil
	redirect "/"
end

get "/signin" do 
	erb :login
end

post "/signin" do
	p params
	user_name_input = params[:name]
	password_input = params[:password]
	user = User.find_by_name(user_name_input)
	p user
	if user && user.password = password_input
		session[:current_user] = user.name
		redirect "/"
	else
		session[:current_user] = nil
		@error = "Username or Password Incorrect"
		erb :login
	end
end

get "/signup" do 
	erb :signup
end

post "/user/create" do 
	if params[:password] == params[:password_confirm]
		password = params[:password]
		name = params[:name]
		if User.all.where("name='#{name}'").empty?
			@user = User.create(name: name, password: password)
			redirect "/signin"
		else
			@error = "Username is already taken"
			erb :signup
		end
	else
		@error = "Passwords Did Not Match!"
		erb :signup
	end
end