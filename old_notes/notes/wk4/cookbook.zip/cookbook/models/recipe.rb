class Recipe < ActiveRecord::Base

	belongs_to :user
	has_many :portions
	has_many :ingredients, through: :portions	

end