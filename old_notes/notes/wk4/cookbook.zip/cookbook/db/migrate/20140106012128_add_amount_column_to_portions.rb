class AddAmountColumnToPortions < ActiveRecord::Migration
  def up
  	add_column :portions, :amount, :integer
  end

  def down
  	remove_column :portions, :amount
  end
end
