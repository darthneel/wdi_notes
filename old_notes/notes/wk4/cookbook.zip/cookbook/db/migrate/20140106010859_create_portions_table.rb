class CreatePortionsTable < ActiveRecord::Migration
  def up
  	create_table :portions do |t|
  		t.string	:unit
  		t.integer	:ingredient_id
  		t.integer	:recipe_id

  		t.timestamps
  	end
  end

  def down
  	drop_table :portions
  end
end
