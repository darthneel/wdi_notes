configure :development do 

	ActiveRecord::Base.establish_connection(
		adapter: "postgresql",
		host: "localhost",
		username: "omardelarosa",
		database: "cookbook_sinatra_test",
		encoding: "utf8"
	)

end