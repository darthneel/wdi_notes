# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
MailingApp::Application.config.secret_token = 'a8e05eeac02641e76499438ab19bbf7c5064c137677e0a8c4eebdc6b4cd169ff5f513b1f021a6716c687274d9fa86add979ea3621c2e022cab8e07b5caaadfa1'
