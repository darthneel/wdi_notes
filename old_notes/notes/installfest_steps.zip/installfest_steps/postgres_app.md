# Postgres App
download and install from http://postgresapp.com/

# Bash Profile
Update your path to include

```
PATH="/Applications/Postgres.app/Contents/MacOS/bin:$PATH"
```