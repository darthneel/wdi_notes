By default RVM will try to install with MacPorts. Since we're using Brew, it's
best to install brew first or specify using homebrew in the autolibs

# Install rvm with homebrew, rails and ruby(1.9.3)
```bash
\curl -L https://get.rvm.io | bash -s stable --autolibs=homebrew --ruby=1.9.3 --rails
```
# in case rvm gives us permission problems

```bash
sudo chown -R username ~
```

# Uninstalling MacPorts
http://bitboxer.de/2010/06/03/moving-from-macports-to-homebrew/