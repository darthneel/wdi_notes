##Homebrew

###Install Homebrew
```bash
ruby -e "$(curl -fsSL https://raw.github.com/mxcl/homebrew/go)"
```
###Brew Doctor
```bash
brew doctor
```
###Install the following:
```bash
brew install hub imagemagick phantomjs redis git mongodb node graphviz
```