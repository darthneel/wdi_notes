#MAC WDI-Installfest 

---

# Postgres App
Download from http://postgresapp.com/

---

##Homebrew

###Install Homebrew

```bash

ruby -e "$(curl -fsSL https://raw.github.com/mxcl/homebrew/go/install)"
```

![image](./01_install_brew.png)

###Brew Doctor

```bash

brew doctor
```

- See what the Doctor says.  You may need to edit your ~/.bash_profile
```bash

echo 'export PATH="/usr/local/bin:/usr/local/sbin:~/bin:$PATH"' >> ~/.bash_profile
```


##git

###Install git

```bash

brew install git
```

- Using the right version?
- We may need to:

<<<<<<< HEAD:block/common/installfest_steps/README.md
###Install Ruby 2.0.0

=======
>>>>>>> 254304f297eb7f89f613b01aff4de53409bcb241:Week_00/installfest_steps/README.md
```bash

git --version
brew link git
```



###Update git config information

```bash

git config --global user.name "YOUR-USERNAME"
git config --global user.email "YOUR-EMAIL-ADDRESS"
git config --global credential.helper cache
```





##rvm & ruby

###Install RVM

```bash

\curl -L https://get.rvm.io | bash -s stable
```

<<<<<<< HEAD:block/common/installfest_steps/README.md
- We may need to:
=======
![image](./02_install_rvm.png)

>>>>>>> 254304f297eb7f89f613b01aff4de53409bcb241:Week_00/installfest_steps/README.md

###Install Ruby 2.0.0
```bash

<<<<<<< HEAD:block/common/installfest_steps/README.md
brew link git
=======
rvm install 2.0.0
>>>>>>> 254304f297eb7f89f613b01aff4de53409bcb241:Week_00/installfest_steps/README.md
```


###Set Ruby 2.0.0 as the default

```bash

rvm --default use ruby-2.0.0
```



---
---


#Ubuntu WDI-Installfest 

---

# Postgres App
Download from http://postgresapp.com/

---

##apt-get

###Install apt-get

```bash

sudo apt-get install curl
```

##rvm & ruby

###Install RVM

```bash

\curl -L https://get.rvm.io | bash -s stable
```

###Add .profile as a source in your .bash_profile

```bash

echo "source ~/.profile" >> /home/developer/.bash_profile
```

##git

###Install git
```bash

sudo apt-get install git-core
```

###Update git config information
```bash

git config --global user.name "YOUR-USERNAME"
git config --global user.email "YOUR-EMAIL-ADDRESS"
git config --global credential.helper cache
```


###Install Ruby 2.0.0

```bash

rvm install 2.0.0 
```

###Login Shell preference
- In terminal go to `Edit -> Profile Preferences`
- Under `Title and Command` check `Run command as a login shell`
- Close preferences and restart terminal

###Set Ruby 2.0.0 as the Default

```bash

rvm --default use ruby-2.0.0
```


<<<<<<< HEAD:block/common/installfest_steps/README.md
##git

###Install git

```bash

sudo apt-get install git-core
```

###Update git config information

```bash

git config --global user.name "YOUR-USERNAME"
git config --global user.email "YOUR-EMAIL-ADDRESS"
git config --global credential.helper cache
```
=======
>>>>>>> 254304f297eb7f89f613b01aff4de53409bcb241:Week_00/installfest_steps/README.md



