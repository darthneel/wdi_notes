var factorial = function(n){
  if (n == 1) {
    return 1
  } else {
    return n * factorial(n-1)
  }
}

var for_loop = function(acc, max, iterator, step){
  if (acc <= max) {
    // call function
    iterator(acc)
    // recursive call
    return for_loop(acc+step, max, iterator, step)
  }
}

var is_less_than_10 = function (n) {
  return n <  10
}

var count_up2 = function(acc, start, stop) {
  if (start === stop ) {
    return acc
  } else {
    acc += 1
    return count_up(acc, start+1, stop)
  }
}