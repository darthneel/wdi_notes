var original_doc_width,
    original_doc_height;

var Shapes = function(container){
  
  container.empty();

  var self = this;
  // takes care of edges
  this.offset = 200
  this.width = original_doc_width 
  this.height = original_doc_height
  // random palette

  window.paper = Raphael(container[0], this.width, this.height);

  this.fetchColors();

  setTimeout(function(){
    self.animate()
  },100)

};

Shapes.prototype.colorCallback = function(json){
  this.colors = json[0].colors
  this.palette = new Palette(json[0])
  this.heading_view = new HeadingView({
    model: this.palette
  })

  this.makeRecursiveCircles(shapes.width/2+this.offset)
}

Shapes.prototype.reload = function(){
  window.paper.clear();
  this.makeRecursiveCircles((shapes.width/2)+this.offset)
}

Shapes.prototype.fetchColors = function(){
  this.colors = [];
  // cross domain ajax ?!?!
  var $script_tag = $('<script src="http://www.colourlovers.com/api/palettes/random?format=json&jsonCallback=shapes.colorCallback"></script>');
  $('body').append($script_tag)
}

Shapes.prototype.randomColorIndex = function() {
  return Math.floor((Math.random()*this.colors.length))
};

Shapes.prototype.makeCircle = function(radius){
  var circle = paper.circle(this.width/2, this.height/2, radius);
    circle.attr("fill", "#"+shapes.colors[this.randomColorIndex()]);
    circle.attr("stroke", "#000");
}

Shapes.prototype.makeRecursiveCircles = function(start_radius){

  if (start_radius >= 0) {
    this.makeCircle(start_radius)
    this.makeRecursiveCircles(start_radius-10)
  }

}

Shapes.prototype.animate = function(){
  var self = this;
  this.interval = setInterval(function(){
    self.reload()
  },100)

}

var HeadingView = Backbone.View.extend({
  initialize: function(){
    this.collapse();
  },
  el: function(){
    return $('.heading');
  },
  events: {
    "click .expander" : "expand",
    "click .close_link" : "collapse",
    "click .next_link" : "change"
  },
  template: function(attributes){
    var html = $('#heading_template').html()
    var template = _.template(html)
    return template(attributes)
  },
  collapse: function(e){
    if (e) e.preventDefault()
    this.is_collapsed = true
    this.$el.addClass("collapsed_heading")
    this.$el.empty();
    var $link = $('<a class="expander" href="#">expand</a>')
    this.$el.html($link)
  },
  change: function(e){
    if (e) e.preventDefault()
    paper.clear()
    clearInterval(shapes.interval)
    window.shapes = new Shapes(canvas_view.$el);
  },
  expand: function(e){
    if (e) e.preventDefault()
    this.is_collapsed = false
    this.$el.removeClass("collapsed_heading")
    this.render();
  },
  render: function(){
    this.$el.html(this.template(this.model.attributes))
    return this;
  }
})

var Palette = Backbone.Model.extend({})

var CanvasView = Backbone.View.extend({
  initialize: function(){
    this.$el.css({
      maxWidth: original_doc_width,
      maxHeight: original_doc_height
    })
    window.shapes = new Shapes(this.$el);
  },
  el: function(){
    return $('#my_canvas');
  }
})

$(function(){

  original_doc_width = $(document).width();
  original_doc_height = $(document).height();

  window.canvas_view = new CanvasView();

  
})