DROP TABLE students;
CREATE TABLE students
(
id serial NOT NULL,
first_name varchar(255),
last_name varchar(255)
);