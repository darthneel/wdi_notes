INSERT INTO students (first_name, last_name) VALUES ('billy','williams');
INSERT INTO students (first_name, last_name) VALUES ('shelly','smith');
INSERT INTO students (first_name, last_name) VALUES ('jenny','mackenzie');
INSERT INTO students (first_name, last_name) VALUES ('bingo','johnson');